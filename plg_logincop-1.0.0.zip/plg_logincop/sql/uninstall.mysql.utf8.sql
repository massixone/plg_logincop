DROP TABLE IF EXISTS `#__user_login_cop`;
